import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, Toplevel
from tkinter import ttk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from fpdf import FPDF
from docx import Document
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import statsmodels.api as sm
from statsmodels.multivariate.manova import MANOVA
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.stattools import adfuller, kpss
from sklearn.cross_decomposition import CCA
from sklearn.cluster import KMeans, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy import stats
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from factor_analyzer import FactorAnalyzer, calculate_bartlett_sphericity, calculate_kmo
from semopy import Model
import networkx as nx
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
import json
from datetime import datetime, timedelta
import datetime as dt
import os
from console_widget import PythonConsole

# Predefined keys for trial and full version
##TRIAL_KEYS = {"TRIAL-1234", "TRIAL-5678"}
##FULL_KEYS = {"FULL-1976", "FULL-1978", "FULL-8492", "FULL-6237", "FULL-1579", "FULL-9401", "FULL-3826", "FULL-7653", "FULL-2485", "FULL-5197", "FULL-6840", "FULL-3072"}

LICENSE_FILE = "license.json"

LICENSE_TEXT = """
LICENSE AGREEMENT FOR EDITABLE CSV TKINTER APPLICATION
Version: 1.0
Date: {activation_date}
Developer: Amchik Solutions, India

1. License Types
   - Trial Version: Limited features, no expiration.
   - Full Version: One-year validity from activation date, requires renewal after expiration.

2. License Activation & Expiration
   - License verification occurs at every startup.
   - Full licenses expire after one year and require renewal.

3. Restrictions
   - Users may not modify, distribute, or reverse-engineer the software.
   - License is non-transferable.

4. Disclaimer
   - Provided "as is" without warranties.
   - Developer is not liable for data loss, security vulnerabilities, or software issues.

5. Contact
   - Email: dr.m.kamakshaiah@gmail.com
   - GitHub: https://github.com/Kamakshaiah
"""



class EditableCSVApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SADSA")
        self.root.state("zoomed")  # Maximize window on launch

        self.data = None
        self.file_path = None
##        self.license_type = "TRIAL"  # Default to trial version

        # Ask for license key
##        self.check_license()


        # Create a menu bar
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)

        # Add 'File' menu
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="Open CSV File", command=self.open_csv)
        self.file_menu.add_command(label="Save Data", command=self.save_data)
        self.file_menu.add_command(label="Save Data File", command=self.save_data_file)
        self.file_menu.add_command(label="Clear Data", command=self.clear_data)
##        self.file_menu.add_command(label="View License", command=self.show_license)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.exit_app)
        

        # Add 'Edit' menu
        self.edit_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Edit", menu=self.edit_menu)
        self.edit_menu.add_command(label="Rename Columns", command=self.rename_columns)
        self.edit_menu.add_command(label="Compute Variable", command=self.compute_variable)
        self.edit_menu.add_command(label="Recode Variable", command=self.recode_variable)
        self.edit_menu.add_command(label="Missing Data Treatment", command=self.missing_data_treatment)
        self.edit_menu.add_command(label="Set Values", command=self.set_values)        

        # Create Treeview for data grid
        self.tree = ttk.Treeview(self.root, show="headings")
        self.tree.pack(expand=True, fill="both")
        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<Button-3>", self.show_right_click_menu)
        
        # Add 'Transformations' menu
        self.transformations_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Transformations", menu=self.transformations_menu)
        self.transformations_menu.add_command(label="Data Simulations", command=self.data_simulations)
        self.transformations_menu.add_command(label="Multivariate Normal Distribution", command=self.generate_multivariate_normal)

        # Add 'Data Decomposition' submenu
        self.decomposition_menu = tk.Menu(self.transformations_menu, tearoff=0)
        self.transformations_menu.add_cascade(label="Data Decomposition", menu=self.decomposition_menu)
        self.decomposition_menu.add_command(label="Cholesky Decomposition", command=lambda: self.perform_decomposition("cholesky"))
        self.decomposition_menu.add_command(label="QR Decomposition", command=lambda: self.perform_decomposition("qr"))
        self.decomposition_menu.add_command(label="SVD Decomposition", command=lambda: self.perform_decomposition("svd"))
        self.decomposition_menu.add_command(label="Eigen Decomposition", command=lambda: self.perform_decomposition("eig"))

        # Add 'Data Standardization' submenu
        self.standardization_menu = tk.Menu(self.transformations_menu, tearoff=0)
        self.transformations_menu.add_cascade(label="Data Standardization", menu=self.standardization_menu)
        self.standardization_menu.add_command(label="Min-Max Scaling", command=lambda: self.perform_standardization("Min-Max"))
        self.standardization_menu.add_command(label="Z-Score Standardization", command=lambda: self.perform_standardization("Z-Score"))
        self.standardization_menu.add_command(label="Decimal Scaling", command=lambda: self.perform_standardization("Decimal Scaling"))
        self.standardization_menu.add_command(label="Log Transformation", command=lambda: self.perform_standardization("Log"))
        self.standardization_menu.add_command(label="Log-Normal Transformation", command=lambda: self.perform_standardization("Log-Normal"))

        # Add 'Data Analytics' menu
        self.analytics_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Data Analytics", menu=self.analytics_menu)
        
        # Descriptive Statistics submenu
        self.descriptive_menu = tk.Menu(self.analytics_menu, tearoff=0)
        self.analytics_menu.add_cascade(label="Descriptive Statistics", menu=self.descriptive_menu)
        self.descriptive_menu.add_command(label="Frequency Tables", command=self.show_frequencies)
        self.descriptive_menu.add_command(label="Summary Statistics", command=self.show_summary_statistics)
        self.descriptive_menu.add_command(label="About Data Set", command=self.show_about_dataset)

        # Inferential Statistics submenu
        self.inferential_menu = tk.Menu(self.analytics_menu, tearoff=0)
        self.analytics_menu.add_cascade(label="Inferential Statistics", menu=self.inferential_menu)
        self.inferential_menu.add_command(label="T-Test", command=self.perform_ttest)
        self.inferential_menu.add_command(label="Chi-Square Test", command=self.perform_chisquare)
        self.inferential_menu.add_command(label="Normality Tests", command=self.perform_normality_tests)
        self.inferential_menu.add_command(label="ANOVA", command=self.perform_anova)
        self.inferential_menu.add_command(label="MANOVA", command=self.perform_manova)

        # Add 'Factor Analysis' menu
        self.factor_analysis_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.analytics_menu.add_cascade(label="Factor Analysis", menu=self.factor_analysis_menu)
        self.factor_analysis_menu.add_command(label="Exploratory Factor Analysis", command=self.perform_efa)
        self.factor_analysis_menu.add_command(label="Confirmatory Factor Analysis", command=self.perform_cfa)

        # Correlation and Regression submenu
        self.corr_reg_menu = tk.Menu(self.analytics_menu, tearoff=0)
        self.analytics_menu.add_cascade(label="Correlation & Regression", menu=self.corr_reg_menu)
        self.corr_reg_menu.add_command(label="Correlation Analysis", command=self.perform_correlation_analysis)
        self.corr_reg_menu.add_command(label="Regression Analysis", command=self.perform_regression_analysis)

        # Cluster Analysis submenu
        self.cluster_menu = tk.Menu(self.analytics_menu, tearoff=0)
        self.analytics_menu.add_cascade(label="Cluster Analysis", menu=self.cluster_menu)
        self.cluster_menu.add_command(label="K-Means Clustering", command=self.perform_kmeans)
        self.cluster_menu.add_command(label="Hierarchical Clustering", command=self.perform_hierarchical)

        # Time Series Analysis submenu
        self.time_series_menu = tk.Menu(self.analytics_menu, tearoff=0)
        self.analytics_menu.add_cascade(label="Time Series Analysis", menu=self.time_series_menu)
        self.time_series_menu.add_command(label="Stationarity Tests", command=self.perform_stationarity_tests)
        self.time_series_menu.add_command(label="Seasonal Decomposition", command=self.perform_seasonal_decomposition)
        self.time_series_menu.add_command(label="Holt-Winters Method", command=self.perform_holt_winters)
        self.time_series_menu.add_command(label="Moving Averages", command=self.perform_moving_averages)

        # Add 'Machine Learning' menu
        self.ml_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Machine Learning", menu=self.ml_menu)
        self.ml_menu.add_command(label="Logistic Regression", command=self.perform_logistic_regression)
        self.ml_menu.add_command(label="Decision Tree", command=self.perform_decision_tree)
        self.ml_menu.add_command(label="Random Forest", command=self.perform_random_forest)
        self.ml_menu.add_command(label="Naive Bayes", command=self.perform_naive_bayes)
        self.ml_menu.add_command(label="K-Nearest Neighbors", command=self.perform_knn)
        self.ml_menu.add_command(label="Neural Network", command=self.perform_neural_network)
        self.ml_menu.add_command(label="Support Vector Machine", command=self.perform_svm)

        # Add 'Plots' menu
        self.plots_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Plots", menu=self.plots_menu)
        self.plots_menu.add_command(label="Generate Plot", command=self.generate_plot)
        
        # Add 'Help' menu
        self.help_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Help", menu=self.help_menu)
        self.help_menu.add_command(label="Python Console", command=self.open_python_console)
        self.help_menu.add_separator()
        self.help_menu.add_command(label="Contact", command=lambda: self.show_message("Contact", "Amchik Solutions, India"))
        self.help_menu.add_command(label="Author", command=lambda: self.show_message("Author", "Dr. Kamakshaiah Musunuru\ndr.m.kamakshaiah@gmail.com\nhttps://github.com/Kamakshaiah"))
        self.help_menu.add_command(label="Version", command=lambda: self.show_message("Version", "V-02.25.0.0.1"))
        self.help_menu.add_command(label="About", command=lambda: self.show_message("About", "This is Software Application for Data Science and Analytics (SADSA) from Amchik Solutions, India."))

        # Create a frame for labels and button
        top_frame = tk.Frame(self.root)
        top_frame.pack(pady=10, fill='x')

        # Left-side label
        left_label = tk.Label(top_frame, text="Software Application for Data Science and Analytics (SADSA)\nAmchik Solutions, India", font=("Arial", 10))
        left_label.pack(side="right", padx=20)

        # Open CSV Button in the center
        self.open_button = tk.Button(top_frame, text="Open CSV File", command=self.open_csv)
        self.open_button.pack(side="left", padx=20)

##        # Status label in the top-right corner of the main window
##        self.status_label = tk.Label(self.root, text=self.get_status_message(), font=("Arial", 8), fg="red" if self.license_type == "TRIAL" else "blue")
##        self.status_label.place(relx=0.999, rely=0.991, anchor='se')

##    def show_license(self):
##        license_window = Toplevel(self.root)
##        license_window.title("License Agreement")
##        license_window.geometry("600x400")
##        
##        text_widget = tk.Text(license_window, wrap=tk.WORD)
##        text_widget.insert(tk.END, LICENSE_TEXT)
##        text_widget.pack(expand=True, fill='both')    
##        
##    def get_status_message(self):
##        return "Running on full mode." if self.license_type == "FULL" else "Running on trial mode."
##
##    def check_license(self):
##        if os.path.exists(LICENSE_FILE):
##            try:
##                with open(LICENSE_FILE, "r") as f:
##                    license_data = json.load(f)
##                key = license_data.get("key", "")
##                activation_date = license_data.get("activation_date", "")
##
##                if key in FULL_KEYS and activation_date:
##                    activation_date = datetime.strptime(activation_date, "%Y-%m-%d")
##                    expiration_date = activation_date + timedelta(days=365)
##                    if datetime.now() > expiration_date:
##                        messagebox.showwarning("License Expired", "Your full version license has expired. Please enter a new key.")
##                        self.request_new_license()
##                    else:
##                        self.license_type = "FULL"
##                else:
##                    self.request_new_license()
##            except (json.JSONDecodeError, KeyError):
##                messagebox.showerror("Error", "License file is corrupted. Please enter a new key.")
##                self.request_new_license()
##        else:
##            self.request_new_license()
##
##    def request_new_license(self):
##        key = simpledialog.askstring("License Key", "Enter your license key:")
##        if key in FULL_KEYS:
##            self.license_type = "FULL"
##            with open(LICENSE_FILE, "w") as f:
##                json.dump({"key": key, "activation_date": datetime.now().strftime("%Y-%m-%d")}, f)
##        else:
##            self.license_type = "TRIAL"
            
    def open_csv(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not self.file_path:
            return
        
        self.data = pd.read_csv(self.file_path)
        self.display_data()
    
    def display_data(self):
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = list(self.data.columns)
        self.tree["show"] = "headings"
        
        for col in self.data.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")
        
        for _, row in self.data.iterrows():
            self.tree.insert("", tk.END, values=list(row))

    def clear_data(self):
        self.data = None
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = []
        messagebox.showinfo("Success", "Data grid cleared successfully!")
    
    def on_double_click(self, event):
        row_id = self.tree.identify_row(event.y)
        col_id = self.tree.identify_column(event.x)
        col_index = int(col_id[1:]) - 1

        if row_id:
            entry = ttk.Entry(self.root)
            entry.place(x=event.x_root - self.root.winfo_rootx(), y=event.y_root - self.root.winfo_rooty())
            entry.insert(0, self.tree.item(row_id, "values")[col_index])
            entry.focus()

            def save_edit(event):
                new_value = entry.get()
                row_values = list(self.tree.item(row_id, "values"))
                row_values[col_index] = new_value
                self.tree.item(row_id, values=row_values)
                entry.destroy()

            entry.bind("<Return>", save_edit)
            entry.bind("<FocusOut>", lambda e: entry.destroy())
    
    def delete_column(self, column_name):
        if column_name in self.data.columns:
            self.data.drop(columns=[column_name], inplace=True)
            self.display_data()
            messagebox.showinfo("Success", f"Column '{column_name}' deleted successfully!")
    
    def delete_row(self, row_id):
        index = self.tree.index(row_id)
        self.data.drop(self.data.index[index], inplace=True)
        self.display_data()
        messagebox.showinfo("Success", "Row deleted successfully!")

    def show_right_click_menu(self, event):
        item = self.tree.identify_row(event.y)
        col_id = self.tree.identify_column(event.x)
        
        menu = tk.Menu(self.root, tearoff=0)
        if item:
            menu.add_command(label="Delete Row", command=lambda: self.delete_row(item))
        elif col_id and col_id != "#0":
            col_index = int(col_id[1:]) - 1
            col_name = self.data.columns[col_index]
            menu.add_command(label="Delete Column", command=lambda: self.delete_column(col_name))
        menu.post(event.x_root, event.y_root)

    def rename_columns(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        rename_window = Toplevel(self.root)
        rename_window.title("Rename/Delete Columns")
        rename_window.geometry("500x500")

        frame = tk.Frame(rename_window)
        frame.pack(pady=10, padx=10, fill='both', expand=True)

        max_columns_per_row = 3  # Arrange items in 3 columns
        entries = {}

        for i, col in enumerate(self.data.columns):
            row_idx = i // max_columns_per_row
            col_idx = (i % max_columns_per_row) * 2

            tk.Label(frame, text=col).grid(row=row_idx, column=col_idx, padx=5, pady=5, sticky="w")
            entry = tk.Entry(frame)
            entry.grid(row=row_idx, column=col_idx + 1, padx=5, pady=5)
            entry.insert(0, col)
            entries[col] = entry

        def apply_changes():
            new_column_names = {col: entry.get() if entry.get().strip() else col for col, entry in entries.items()}
            self.data.rename(columns=new_column_names, inplace=True)
            self.display_data()
            messagebox.showinfo("Success", "Column names updated successfully!")
            rename_window.destroy()

        apply_button = tk.Button(rename_window, text="Apply", command=apply_changes)
        apply_button.pack(pady=10)
        
    def set_values(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        set_values_window = Toplevel(self.root)
        set_values_window.title("Set Values")
        set_values_window.geometry("400x400")

        tk.Label(set_values_window, text="Select Variable:").pack()
        column_var = tk.StringVar(set_values_window)
        column_dropdown = ttk.Combobox(set_values_window, textvariable=column_var, values=list(self.data.columns))
        column_dropdown.pack()

        def process_set_values():
            selected_col = column_var.get()
            if selected_col not in self.data.columns:
                messagebox.showerror("Error", "Invalid column selection!")
                return
            
            unique_values = self.data[selected_col].dropna().unique()
            value_map = {}
            
            for value in unique_values:
                new_label = simpledialog.askstring("Set Values", f"Enter name for {value}:")
                value_map[value] = new_label
            
            new_col_name = selected_col + "_Labeled"
            self.data[new_col_name] = self.data[selected_col].map(value_map)
            
            self.display_data()
            messagebox.showinfo("Success", "Values set successfully!")
            set_values_window.destroy()
        
        apply_button = tk.Button(set_values_window, text="Apply", command=process_set_values)
        apply_button.pack()

    def save_data(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return
        
        new_data = []
        for row_id in self.tree.get_children():
            new_data.append(self.tree.item(row_id, "values"))
        
        self.data = pd.DataFrame(new_data, columns=self.data.columns)
        messagebox.showinfo("Success", "Data saved successfully in the grid!")
    
    def save_data_file(self):
        if self.data is None:
            messagebox.showerror("Error", "No data to save!")
            return
        
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV Files", "*.csv")])
        if file_path:
            self.data.to_csv(file_path, index=False)
            messagebox.showinfo("Success", "Data saved successfully!")
    
    def exit_app(self):
        self.root.quit()

    def compute_variable(self):
        expression = simpledialog.askstring("Compute Variable", "Enter formula (e.g., col1 + col2, log(col3)):")
        if not expression:
            return
        try:
            self.data["Computed_Var"] = self.data.eval(expression)
            self.display_data()
            messagebox.showinfo("Success", "Variable computed successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Invalid expression: {e}")

    def recode_variable(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        recode_window = Toplevel(self.root)
        recode_window.title("Recode Variable")
        recode_window.geometry("400x400")

        column_label = tk.Label(recode_window, text="Select Variable:")
        column_label.pack()
        column_var = tk.StringVar(recode_window)
        column_dropdown = ttk.Combobox(recode_window, textvariable=column_var, values=list(self.data.columns))
        column_dropdown.pack()

        def process_recode():
            selected_col = column_var.get()
            if selected_col not in self.data.columns:
                messagebox.showerror("Error", "Invalid column selection!")
                return
            
            if pd.api.types.is_numeric_dtype(self.data[selected_col]):
                min_value = float(simpledialog.askstring("Numeric Recode", "Enter minimum value:"))
                max_value = float(simpledialog.askstring("Numeric Recode", "Enter maximum value:"))
                num_categories = int(simpledialog.askstring("Numeric Recode", "Enter number of categories:"))
                
                intervals = np.linspace(min_value, max_value, num_categories + 1)
                category_names = [simpledialog.askstring("Category Name", f"Enter name for category {i+1} ({intervals[i]:.2f} - {intervals[i+1]:.2f}):") 
                                  for i in range(num_categories)]
                
                self.data[selected_col + "_Recoded"] = pd.cut(self.data[selected_col], bins=intervals, labels=category_names, include_lowest=True)
            else:
                unique_values = self.data[selected_col].unique()
                recode_dict = {}
                for value in unique_values:
                    new_value = simpledialog.askstring("Recode Variable", f"Enter numeric value for '{value}':")
                    recode_dict[value] = new_value
                
                self.data[selected_col + "_Recoded"] = self.data[selected_col].replace(recode_dict)
            
            self.display_data()
            messagebox.showinfo("Success", "Variable recoded successfully!")
            recode_window.destroy()
        
        apply_btn = tk.Button(recode_window, text="Apply Recode", command=process_recode)
        apply_btn.pack()

    
    def missing_data_treatment(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        missing_window = Toplevel(self.root)
        missing_window.title("Missing Data Treatment")
        missing_window.geometry("400x300")

        tk.Label(missing_window, text="Select Variable:").pack()
        column_var = tk.StringVar(missing_window)
        column_dropdown = ttk.Combobox(missing_window, textvariable=column_var, values=list(self.data.columns))
        column_dropdown.pack()

        tk.Label(missing_window, text="Select Method:").pack()
        method_var = tk.StringVar(missing_window)
        method_dropdown = ttk.Combobox(missing_window, textvariable=method_var, 
                                       values=["Mean", "Median", "Mode", "Drop Rows", "Drop Column"])
        method_dropdown.pack()

        def apply_treatment():
            selected_col = column_var.get()
            method = method_var.get()
            
            if selected_col not in self.data.columns:
                messagebox.showerror("Error", "Invalid column selection!")
                return

            if method == "Mean":
                self.data[selected_col].fillna(self.data[selected_col].mean(), inplace=True)
            elif method == "Median":
                self.data[selected_col].fillna(self.data[selected_col].median(), inplace=True)
            elif method == "Mode":
                self.data[selected_col].fillna(self.data[selected_col].mode().iloc[0], inplace=True)
            elif method == "Drop Rows":
                self.data.dropna(subset=[selected_col], inplace=True)
            elif method == "Drop Column":
                self.data.drop(columns=[selected_col], inplace=True)
            else:
                messagebox.showerror("Error", "Invalid method selected!")
                return
            
            self.display_data()
            messagebox.showinfo("Success", "Missing data treated successfully!")
            missing_window.destroy()
        
        tk.Button(missing_window, text="Apply", command=apply_treatment).pack()

    def data_simulations(self):
        num_vars = simpledialog.askinteger("Data Simulations", "Enter number of variables:")
        num_rows = simpledialog.askinteger("Data Simulations", "Enter number of rows:")
        if not num_vars or not num_rows:
            return
        
        new_data = {}
        for i in range(num_vars):
            var_name = simpledialog.askstring("Data Simulations", f"Enter name for variable {i+1}:")
            dtype = simpledialog.askstring("Data Simulations", f"Enter type for {var_name} (int, float, category):")
            
            if dtype == "category":
                categories = simpledialog.askstring("Data Simulations", f"Enter categories for {var_name}, separated by commas:")
                new_data[var_name] = np.random.choice(categories.split(","), num_rows)
            elif dtype == "int":
                start = simpledialog.askinteger("Data Simulations", f"Enter start value for {var_name}:")
                stop = simpledialog.askinteger("Data Simulations", f"Enter stop value for {var_name}:")
                new_data[var_name] = np.random.randint(start, stop, num_rows)
            elif dtype == "float":
                start = simpledialog.askfloat("Data Simulations", f"Enter start value for {var_name}:")
                stop = simpledialog.askfloat("Data Simulations", f"Enter stop value for {var_name}:")
                new_data[var_name] = np.random.uniform(start, stop, num_rows)
        
        df_new = pd.DataFrame(new_data)
        self.data = pd.concat([self.data, df_new], axis=1) if self.data is not None else df_new
        self.display_data()
        messagebox.showinfo("Success", "Data simulated successfully!")

    def generate_multivariate_normal(self):
        variable_names = simpledialog.askstring("Input", "Enter variable names (comma-separated):")
        means_input = simpledialog.askstring("Input", "Enter means for each variable (comma-separated):")
        cov_input = simpledialog.askstring("Input", "Enter covariance matrix (comma-separated, row-wise):")
        num_samples = simpledialog.askinteger("Input", "Enter number of samples:", minvalue=1)
        
        if not variable_names or not means_input or not cov_input or not num_samples:
            messagebox.showerror("Error", "Invalid input values.")
            return
        
        variable_names = [var.strip() for var in variable_names.split(',')]
        means = np.array([float(m.strip()) for m in means_input.split(',')])
        cov_values = np.array([float(c.strip()) for c in cov_input.split(',')])
        num_variables = len(variable_names)
        
        if len(means) != num_variables or len(cov_values) != num_variables ** 2:
            messagebox.showerror("Error", "Mismatch in dimensions of means or covariance matrix.")
            return
        
        cov_matrix = cov_values.reshape(num_variables, num_variables)
        simulated_data = np.random.multivariate_normal(means, cov_matrix, num_samples)
        df_new = pd.DataFrame(simulated_data, columns=variable_names)
        
        if self.data is None:
            self.data = df_new
        else:
            self.data = pd.concat([self.data, df_new], axis=1)
        
        self.display_data()
        messagebox.showinfo("Success", "Multivariate normal data appended to the data grid.")
        
##    def generate_multivariate_normal(self):
##        var_names = simpledialog.askstring("Input", "Enter variable names (comma-separated):")
##        means_input = simpledialog.askstring("Input", "Enter means for each variable (comma-separated):")
##        num_samples = simpledialog.askinteger("Input", "Enter number of samples:", minvalue=1)
##        
##        if not var_names or not means_input or not num_samples:
##            messagebox.showerror("Error", "Invalid input values.")
##            return
##        
##        var_names = [name.strip() for name in var_names.split(',')]
##        means = [float(mean.strip()) for mean in means_input.split(',')]
##        num_variables = len(var_names)
##        
##        if len(means) != num_variables:
##            messagebox.showerror("Error", "Number of means must match number of variables.")
##            return
##        
##        cov_matrix = np.identity(num_variables)  # Default identity covariance matrix
##        
##        simulated_data = np.random.multivariate_normal(means, cov_matrix, num_samples)
##        df_new = pd.DataFrame(simulated_data, columns=var_names)
##        
##        if self.data is None:
##            self.data = df_new
##        else:
##            self.data = pd.concat([self.data, df_new], axis=1)
##        
##        self.display_data()
##        messagebox.showinfo("Success", "Multivariate normal data appended to the data grid.")

    def perform_standardization(self, method):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return
        
        selected_col = simpledialog.askstring("Select Column", "Enter the column name for standardization:")
        if selected_col not in self.data.columns:
            messagebox.showerror("Error", "Invalid column name!")
            return
        
        new_col_name = f"{selected_col}_{method}"  # Append transformation name to column
        df = self.data.copy()
        
        if method == "Min-Max":
            scaler = MinMaxScaler()
            df[new_col_name] = scaler.fit_transform(df[[selected_col]])
        elif method == "Z-Score":
            scaler = StandardScaler()
            df[new_col_name] = scaler.fit_transform(df[[selected_col]])
        elif method == "Decimal Scaling":
            max_abs = df[selected_col].abs().max()
            df[new_col_name] = df[selected_col] / (10 ** np.ceil(np.log10(max_abs)))
        elif method == "Log":
            df[new_col_name] = np.log(df[selected_col] + 1)
        elif method == "Log-Normal":
            df[new_col_name] = np.exp(df[selected_col])
        
        self.data = df  # Update main data
        self.display_data()
        messagebox.showinfo("Success", f"{method} applied successfully to {selected_col}. New variable added: {new_col_name}")

##    def perform_decomposition(self, method):
##        if self.data is None:
##            messagebox.showerror("Error", "No data loaded!")
##            return
##        
##        selected_columns = simpledialog.askstring("Select Columns", "Enter column names for decomposition (comma-separated):")
##        if not selected_columns:
##            messagebox.showerror("Error", "No columns selected!")
##            return
##        
##        selected_columns = [col.strip() for col in selected_columns.split(',')]
##        if any(col not in self.data.columns for col in selected_columns):
##            messagebox.showerror("Error", "Invalid column names!")
##            return
##        
##        matrix = self.data[selected_columns].values.astype(float)
##        
##        try:
##            if method == "cholesky":
##                result = np.linalg.cholesky(matrix)
##            elif method == "qr":
##                result, _ = np.linalg.qr(matrix)
##            elif method == "svd":
##                result = np.linalg.svd(matrix, full_matrices=False)[0]
##            elif method == "eig":
##                result = np.linalg.eig(matrix)[1]
##            else:
##                messagebox.showerror("Error", "Invalid decomposition method!")
##                return
##            
##            df_result = pd.DataFrame(result, columns=[f"{method}_comp_{i+1}" for i in range(result.shape[1])])
##            self.data = pd.concat([self.data, df_result], axis=1)
##            self.display_data()
##            messagebox.showinfo("Success", f"{method.capitalize()} decomposition performed successfully! Results appended to the data grid.")
##        except np.linalg.LinAlgError as e:
##            messagebox.showerror("Error", f"Decomposition failed: {e}")

    def perform_decomposition(self, method):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return
        
        selected_columns = simpledialog.askstring("Select Columns", "Enter column names for decomposition (comma-separated):")
        if not selected_columns:
            messagebox.showerror("Error", "No columns selected!")
            return
        
        selected_columns = [col.strip() for col in selected_columns.split(',')]
        if any(col not in self.data.columns for col in selected_columns):
            messagebox.showerror("Error", "Invalid column names!")
            return
        
        matrix = self.data[selected_columns].values.astype(float)
        
        try:
            if method == "cholesky":
                matrix = matrix @ matrix.T  # Ensure the matrix is symmetric positive definite
                result = np.linalg.cholesky(matrix)
            elif method == "qr":
                result, _ = np.linalg.qr(matrix)
            elif method == "svd":
                result = np.linalg.svd(matrix, full_matrices=False)[0]
            elif method == "eig":
                result = np.linalg.eig(matrix)[1]
            else:
                messagebox.showerror("Error", "Invalid decomposition method!")
                return
            
            df_result = pd.DataFrame(result, columns=[f"{method}_comp_{i+1}" for i in range(result.shape[1])])
            self.data = pd.concat([self.data, df_result], axis=1)
            self.display_data()
            messagebox.showinfo("Success", f"{method.capitalize()} decomposition performed successfully! Results appended to the data grid.")
        except np.linalg.LinAlgError as e:
            messagebox.showerror("Error", f"Decomposition failed: {e}")

    def show_report_window(self, data, title, fig=None):
        report_window = Toplevel(self.root)
        report_window.title(title)
        report_window.geometry("800x600")
        
        frame = tk.Frame(report_window)
        frame.pack(fill='both', expand=True)
        
        text_widget = tk.Text(frame, wrap=tk.WORD)
        if isinstance(data, dict):
            for key, value in data.items():
                text_widget.insert(tk.END, f"{key}\n{value.to_string()}\n\n")
        elif isinstance(data, str):
            text_widget.insert(tk.END, data)
        else:
            text_widget.insert(tk.END, f"{title}\n\n{data.to_string()}")
        text_widget.pack(expand=True, fill='both', side='left')
        
        if fig:
            canvas = FigureCanvasTkAgg(fig, master=frame)
            canvas.draw()
            canvas.get_tk_widget().pack(expand=True, fill='both', side='right')
        
        download_button = tk.Button(report_window, text="Download Report", command=lambda: self.download_report(data, title, fig))
        download_button.pack(anchor='nw', padx=10, pady=5)

    
    def download_report(self, data, title, fig=None):
##        if self.license_type == "FULL":
        file_path = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word Document", "*.docx"), ("PDF File", "*.pdf")])
        if not file_path:
            return

        temp_chart_path = "temp_chart.png"
        try:
            if file_path.endswith(".docx"):
                doc = Document()
                doc.add_paragraph(title)
                if isinstance(data, dict):
                    for key, value in data.items():
                        doc.add_paragraph(f"{key}\n{value.to_string()}\n\n")
                elif isinstance(data, str):
                    doc.add_paragraph(data)
                else:
                    doc.add_paragraph(data.to_string())
                if fig:
                    fig.savefig(temp_chart_path)
                    doc.add_picture(temp_chart_path)
                doc.save(file_path)
            elif file_path.endswith(".pdf"):
                pdf = FPDF()
                pdf.add_page()
                pdf.set_font("Arial", size=12)
                pdf.multi_cell(200, 10, title + "\n\n")
                if isinstance(data, dict):
                    for key, value in data.items():
                        pdf.multi_cell(200, 10, f"{key}\n{value.to_string()}\n\n")
                elif isinstance(data, str):
                    pdf.multi_cell(200, 10, data)
                else:
                    pdf.multi_cell(200, 10, data.to_string())
                if fig:
                    fig.savefig(temp_chart_path)
                    pdf.image(temp_chart_path, x=10, y=pdf.get_y(), w=180)
                pdf.output(file_path)
        finally:
            if os.path.exists(temp_chart_path):
                os.remove(temp_chart_path)

        messagebox.showinfo("Success", "Report saved successfully!")
            
##        else:
##            messagebox.showinfo("Feature Locked", "Unlock this feature by buying a license. Go to Help menu for more details.")
            
    def show_frequencies(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("Frequencies", "Enter categorical variables (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if not selected_columns:
            messagebox.showerror("Error", "Invalid column names!")
            return

        result = {col: self.data[col].value_counts() for col in selected_columns}
        fig, ax = plt.subplots()
        self.data[selected_columns].apply(pd.Series.value_counts).plot(kind='bar', ax=ax)
        self.show_report_window(result, "Frequency Tables", fig)
    
    def show_summary_statistics(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("Summary Statistics", "Enter numeric variables (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if not selected_columns:
            messagebox.showerror("Error", "Invalid column names!")
            return

        result = self.data[selected_columns].describe()
        fig, ax = plt.subplots()
        self.data[selected_columns].plot(kind='box', ax=ax)
        self.show_report_window(result, "Summary Statistics", fig)

    def show_about_dataset(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return
        
        # Gather metadata information
        num_rows = len(self.data)
        num_cols = len(self.data.columns)
        
        # Create list of variable names
        variable_names = ", ".join(self.data.columns)
        
        # Create detailed information about each variable
        variable_info = []
        for col in self.data.columns:
            col_dtype = str(self.data[col].dtype)
            count = self.data[col].count()
            missing = self.data[col].isna().sum()
            
            variable_info.append({
                'Variable': col,
                'Type': col_dtype,
                'Count': count,
                'Missing': missing,
                'Unique': self.data[col].nunique()
            })
        
        # Create DataFrames for display
        variable_df = pd.DataFrame(variable_info)
        
        # Create overall dataset metadata
        metadata = {
            'Metric': ['Number of Variables', 'Number of Rows', 'Total Cells', 'Missing Cells', 'Missing %'],
            'Value': [
                num_cols,
                num_rows,
                num_rows * num_cols,
                self.data.isna().sum().sum(),
                f"{(self.data.isna().sum().sum() / (num_rows * num_cols) * 100):.2f}%"
            ]
        }
        metadata_df = pd.DataFrame(metadata)
        
        # Create a combined report
        report_text = f"""
================== DATASET INFORMATION ==================

Overview:
---------
Number of Variables (Columns): {num_cols}
Number of Rows: {num_rows}
Total Cells: {num_rows * num_cols}
Missing Cells: {self.data.isna().sum().sum()}
Missing Percentage: {(self.data.isna().sum().sum() / (num_rows * num_cols) * 100):.2f}%

Variable Names (comma-separated):
--------------------------------
{variable_names}

Variable Details:
-----------------
{variable_df.to_string(index=False)}

Dataset Summary:
----------------
File Name: {self.file_path if self.file_path else 'No file loaded'}
"""
        
        # Display in report window
        self.show_report_window(report_text, "About Data Set")

    def perform_ttest(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("T-Test", "Enter two numeric variables (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(selected_columns) != 2:
            messagebox.showerror("Error", "Please enter exactly two numeric variables!")
            return

        t_stat, p_value = stats.ttest_ind(self.data[selected_columns[0]], self.data[selected_columns[1]], nan_policy='omit')
        result = pd.DataFrame({"Statistic": [t_stat], "P-Value": [p_value]})
        fig, ax = plt.subplots()
        self.data.boxplot(column=selected_columns, ax=ax)
        self.show_report_window(result, "T-Test Results", fig)
    
    def perform_chisquare(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("Chi-Square Test", "Enter two categorical variables (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(selected_columns) != 2:
            messagebox.showerror("Error", "Please enter exactly two categorical variables!")
            return

        contingency_table = pd.crosstab(self.data[selected_columns[0]], self.data[selected_columns[1]])
        chi2, p, dof, expected = stats.chi2_contingency(contingency_table)
        result = pd.DataFrame({"Chi-Square": [chi2], "P-Value": [p], "Degrees of Freedom": [dof]})
        fig, ax = plt.subplots()
        contingency_table.plot(kind='bar', stacked=True, ax=ax)
        self.show_report_window(result, "Chi-Square Test Results", fig)
    
    def perform_normality_tests(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("Normality Tests", "Enter numeric variables (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if not selected_columns:
            messagebox.showerror("Error", "Please enter valid numeric variables!")
            return

        result_dict = {}
        for col in selected_columns:
            shapiro_test = stats.shapiro(self.data[col].dropna())
            ks_test = stats.kstest(self.data[col].dropna(), 'norm')
            result_dict[col] = {
                "Shapiro-Wilk Statistic": shapiro_test.statistic,
                "Shapiro-Wilk P-Value": shapiro_test.pvalue,
                "Kolmogorov-Smirnov Statistic": ks_test.statistic,
                "Kolmogorov-Smirnov P-Value": ks_test.pvalue
            }
        
        result_df = pd.DataFrame(result_dict).T
        fig, ax = plt.subplots()
        self.data[selected_columns].hist(ax=ax)
        self.show_report_window(result_df, "Normality Test Results", fig)

    def perform_anova(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("ANOVA", "Enter numeric dependent variable and categorical independent variable (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(selected_columns) != 2:
            messagebox.showerror("Error", "Please enter one numeric and one categorical variable!")
            return

        dependent_var, independent_var = selected_columns
        groups = [self.data[self.data[independent_var] == cat][dependent_var].dropna() for cat in self.data[independent_var].unique()]
        f_stat, p_value = stats.f_oneway(*groups)
        result = pd.DataFrame({"F-Statistic": [f_stat], "P-Value": [p_value]})
        fig, ax = plt.subplots()
        self.data.boxplot(column=[dependent_var], by=independent_var, ax=ax)
        self.show_report_window(result, "ANOVA Results", fig)
    
    def perform_manova(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("MANOVA", "Enter dependent variables (comma-separated) and independent variable:")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(selected_columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent variable and one independent variable!")
            return

        dependent_vars = selected_columns[:-1]
        independent_var = selected_columns[-1]
        
        formula = ' + '.join(dependent_vars) + ' ~ ' + independent_var
        model = MANOVA.from_formula(formula, data=self.data)
        result = model.mv_test()
        result_df = pd.DataFrame(result.results)
        fig, ax = plt.subplots()
        pd.plotting.scatter_matrix(self.data[dependent_vars], ax=ax, diagonal='hist')
        self.show_report_window(result_df, "MANOVA Results", fig)

    def perform_efa(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("Exploratory Factor Analysis", "Enter numeric variables (comma-separated):")
        if not selected_columns:
            return

        selected_columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if not selected_columns:
            messagebox.showerror("Error", "Please enter valid numeric variables!")
            return

        df = self.data[selected_columns].dropna()
        chi_square_value, p_value = calculate_bartlett_sphericity(df)
        kmo_all, kmo_model = calculate_kmo(df)
        
        fa = FactorAnalyzer(n_factors=2, rotation="varimax")
        fa.fit(df)
        result_df = pd.DataFrame(fa.loadings_, index=selected_columns, columns=["Factor 1", "Factor 2"])
        
        fig, ax = plt.subplots()
        ax.matshow(fa.loadings_, cmap="coolwarm")
        ax.set_xticks(range(len(result_df.columns)))
        ax.set_xticklabels(result_df.columns)
        ax.set_yticks(range(len(result_df.index)))
        ax.set_yticklabels(result_df.index)
        
        scree_fig, scree_ax = plt.subplots()
        scree_ax.plot(range(1, len(fa.get_eigenvalues()[0]) + 1), fa.get_eigenvalues()[0], marker='o', linestyle='--')
        scree_ax.set_title("Scree Plot")
        scree_ax.set_xlabel("Factors")
        scree_ax.set_ylabel("Eigenvalue")
        
        bartlett_kmo_results = pd.DataFrame({
            "Bartlett's Chi-Square": [chi_square_value],
            "Bartlett's P-Value": [p_value],
            "KMO Overall": [kmo_model]
        })
        
        self.show_report_window(result_df, "Exploratory Factor Analysis", fig)
        self.show_report_window(bartlett_kmo_results, "Bartlett's & KMO Test Results", scree_fig)
    
    def perform_cfa(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return
        
        num_factors = simpledialog.askinteger("Confirmatory Factor Analysis", "Enter the number of factors:")
        if not num_factors or num_factors < 1:
            return
        
        factor_model = []
        selected_columns = set()
        
        for i in range(num_factors):
            factor_name = simpledialog.askstring("Factor Name", f"Enter name for Factor {i+1}:")
            if not factor_name:
                return
            
            variables = simpledialog.askstring("Factor Variables", f"Enter variables for {factor_name} (comma-separated):")
            if not variables:
                return
            
            var_list = [var.strip() for var in variables.split(',') if var.strip() in self.data.columns]
            if not var_list:
                messagebox.showerror("Error", "Invalid variables selected!")
                return
            
            factor_model.append(f"{factor_name} =~ {' + '.join(var_list)}")
            selected_columns.update(var_list)
        
        model_description = "\n".join(factor_model)
        
        try:
            df = self.data[list(selected_columns)].dropna()
            model = Model(model_description)
            model.fit(df)
            result_df = pd.DataFrame(model.inspect())
        except Exception as e:
            messagebox.showerror("Error", f"CFA Model error: {e}")
            return
        
        # Create SEM Path Diagram using networkx
        fig, ax = plt.subplots()
        G = nx.DiGraph()
        
        for line in factor_model:
            parts = line.split('=~')
            if len(parts) == 2:
                latent, observed_vars = parts[0].strip(), parts[1].split('+')
                G.add_node(latent, color='red')
                for obs in observed_vars:
                    obs = obs.strip()
                    G.add_node(obs, color='blue')
                    G.add_edge(latent, obs)
        
        pos = nx.spring_layout(G)
        colors = ['red' if node in [f.split('=~')[0].strip() for f in factor_model] else 'blue' for node in G.nodes]
        nx.draw(G, pos, with_labels=True, node_color=colors, edge_color='gray', ax=ax)
        ax.set_title("CFA Structural Equation Model")
        
        self.show_report_window(result_df, "Confirmatory Factor Analysis", fig)

    def perform_correlation_analysis(self):
        analysis_type = simpledialog.askstring("Correlation Analysis", "Choose analysis type: bivariate, multivariate, canonical")
        if not analysis_type:
            return
        
        if analysis_type == "bivariate":
            selected_columns = simpledialog.askstring("Bivariate Correlation", "Enter two numeric variables (comma-separated):")
            if not selected_columns or ',' not in selected_columns:
                messagebox.showerror("Error", "Please enter exactly two variables separated by a comma.")
                return
            col1, col2 = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
            if len({col1, col2}) < 2:
                messagebox.showerror("Error", "Invalid variable selection!")
                return
            corr_coeff, p_value = stats.pearsonr(self.data[col1], self.data[col2])
            result = pd.DataFrame({"Correlation Coefficient": [corr_coeff], "P-Value": [p_value]})
            fig, ax = plt.subplots()
            ax.scatter(self.data[col1], self.data[col2])
            ax.set_title("Bivariate Correlation")
        
        elif analysis_type == "multivariate":
            selected_columns = simpledialog.askstring("Multivariate Correlation", "Enter multiple numeric variables (comma-separated):")
            columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
            if not columns:
                messagebox.showerror("Error", "Invalid variable selection!")
                return
            result = self.data[columns].corr()
            fig, ax = plt.subplots()
            cax = ax.matshow(result, cmap="coolwarm")
            plt.colorbar(cax)
        
        elif analysis_type == "canonical":
            selected_columns = simpledialog.askstring("Canonical Correlation", "Enter two sets of variables (comma-separated, separated by |):")
            if not selected_columns or '|' not in selected_columns:
                messagebox.showerror("Error", "Please enter two sets of variables separated by '|'")
                return
            set1, set2 = selected_columns.split('|')
            set1 = [col.strip() for col in set1.split(',') if col.strip() in self.data.columns]
            set2 = [col.strip() for col in set2.split(',') if col.strip() in self.data.columns]
            if not set1 or not set2:
                messagebox.showerror("Error", "Invalid variable selection!")
                return
            X, Y = self.data[set1], self.data[set2]
            cca_model = CCA()
            cca_model.fit(X, Y)
            canonical_scores = cca_model.score(X, Y)
            result = pd.DataFrame({"Canonical Correlation Score": [canonical_scores]})
            fig, ax = plt.subplots()
            ax.plot(cca_model.transform(X)[:, 0], marker='o')
        
        self.show_report_window(result, "Correlation Analysis", fig)        
    
    def perform_regression_analysis(self):
        analysis_type = simpledialog.askstring("Regression Analysis", "Choose analysis type: simple, multiple, glm")
        if not analysis_type:
            return
        
        selected_columns = simpledialog.askstring("Regression Analysis", "Enter dependent variable and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X = sm.add_constant(self.data[independent_vars])
        Y = self.data[dependent_var]
        
        if analysis_type == "simple" and len(independent_vars) == 1:
            model = sm.OLS(Y, X).fit()
        elif analysis_type == "multiple" and len(independent_vars) > 1:
            model = sm.OLS(Y, X).fit()
        elif analysis_type == "glm":
            model = sm.GLM(Y, X, family=sm.families.Gaussian()).fit()
        else:
            messagebox.showerror("Error", "Invalid regression type for the selected variables.")
            return
        
        result = pd.DataFrame(model.summary().tables[1])
        fig, ax = plt.subplots()
        ax.scatter(model.fittedvalues, Y)
        ax.set_xlabel('Fitted Values')
        ax.set_ylabel('Observed Values')
        ax.axhline(y=0, color='red', linestyle='--')
        ax.set_title(f"{analysis_type.capitalize()} Regression Residual Plot")
        
        self.show_report_window(result, "Regression Analysis", fig)

    def perform_kmeans(self):
        num_clusters = simpledialog.askinteger("K-Means Clustering", "Enter number of clusters:")
        if not num_clusters or num_clusters < 1:
            return
        
        selected_columns = simpledialog.askstring("K-Means Clustering", "Enter numeric variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if not columns:
            messagebox.showerror("Error", "Invalid variable selection!")
            return
        
        X = self.data[columns]
        kmeans = KMeans(n_clusters=num_clusters, random_state=42)
        self.data['Cluster'] = kmeans.fit_predict(X)
        
        fig, ax = plt.subplots()
        scatter = ax.scatter(X[columns[0]], X[columns[1]], c=self.data['Cluster'], cmap='viridis')
        ax.set_title("K-Means Clustering")
        plt.colorbar(scatter)
        
        self.show_report_window(pd.DataFrame(kmeans.cluster_centers_, columns=columns), "K-Means Clustering", fig)
    
    def perform_hierarchical(self):
        selected_columns = simpledialog.askstring("Hierarchical Clustering", "Enter numeric variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if not columns:
            messagebox.showerror("Error", "Invalid variable selection!")
            return
        
        X = self.data[columns]
        linkage_matrix = linkage(X, method='ward')
        
        fig, ax = plt.subplots(figsize=(8, 6))
        dendrogram(linkage_matrix, labels=self.data.index, ax=ax)
        ax.set_title("Hierarchical Clustering Dendrogram")
        ax.set_ylabel("Distance")
        
        self.show_report_window(pd.DataFrame(linkage_matrix, columns=["Cluster 1", "Cluster 2", "Distance", "Sample Count"]), "Hierarchical Clustering", fig)

    def perform_stationarity_tests(self):
        selected_column = simpledialog.askstring("Stationarity Tests", "Enter the time series variable:")
        if not selected_column or selected_column not in self.data.columns:
            messagebox.showerror("Error", "Invalid variable selection!")
            return
        
        df = self.data[[selected_column]].dropna()
        adf_test = adfuller(df[selected_column])
        kpss_test = kpss(df[selected_column], regression='c')
        
        result = pd.DataFrame({
            "Test": ["ADF Test", "KPSS Test"],
            "Statistic": [adf_test[0], kpss_test[0]],
            "P-Value": [adf_test[1], kpss_test[1]]
        })
        
        fig, ax = plt.subplots()
        df[selected_column].plot(ax=ax, title="Time Series Plot")
        
        self.show_report_window(result, "Stationarity Tests", fig)

    def perform_seasonal_decomposition(self):
        selected_column = simpledialog.askstring("Seasonal Decomposition", "Enter the time series variable:")
        if not selected_column or selected_column not in self.data.columns:
            messagebox.showerror("Error", "Invalid variable selection!")
            return
        
        df = self.data[[selected_column]].dropna()
        result = seasonal_decompose(df, model='additive', period=12)
        
        fig, axes = plt.subplots(4, 1, figsize=(10, 8))
        result.observed.plot(ax=axes[0], title='Observed')
        result.trend.plot(ax=axes[1], title='Trend')
        result.seasonal.plot(ax=axes[2], title='Seasonal')
        result.resid.plot(ax=axes[3], title='Residual')
        
        self.show_report_window(pd.DataFrame({'Trend': result.trend, 'Seasonal': result.seasonal, 'Residual': result.resid}), "Seasonal Decomposition", fig)

    
    def perform_holt_winters(self):
        selected_column = simpledialog.askstring("Holt-Winters Method", "Enter the time series variable:")
        if not selected_column or selected_column not in self.data.columns:
            messagebox.showerror("Error", "Invalid variable selection!")
            return
        
        df = self.data[[selected_column]].dropna()
        model = ExponentialSmoothing(df, trend='add', seasonal='add', seasonal_periods=12).fit()
        df['Forecast'] = model.fittedvalues
        
        mse = np.mean((df[selected_column] - df['Forecast'])**2)
        mae = np.mean(np.abs(df[selected_column] - df['Forecast']))
        rmse = np.sqrt(mse)
        metrics = pd.DataFrame({'Metric': ['MSE', 'MAE', 'RMSE'], 'Value': [mse, mae, rmse]})
        
        fig, ax = plt.subplots()
        df[selected_column].plot(ax=ax, label='Original')
        df['Forecast'].plot(ax=ax, label='Holt-Winters Forecast', linestyle='dashed')
        ax.legend()
        
        self.show_report_window(metrics, "Holt-Winters - Fitness Measures", fig)
    
    def perform_moving_averages(self):
        selected_column = simpledialog.askstring("Moving Averages", "Enter the time series variable:")
        window_size = simpledialog.askinteger("Moving Averages", "Enter window size:")
        if not selected_column or selected_column not in self.data.columns or not window_size:
            messagebox.showerror("Error", "Invalid input!")
            return
        
        df = self.data[[selected_column]].dropna()
        df['Moving Average'] = df[selected_column].rolling(window=window_size).mean()
        
        mse = np.mean((df[selected_column] - df['Moving Average'])**2)
        mae = np.mean(np.abs(df[selected_column] - df['Moving Average']))
        rmse = np.sqrt(mse)
        metrics = pd.DataFrame({'Metric': ['MSE', 'MAE', 'RMSE'], 'Value': [mse, mae, rmse]})
        
        fig, ax = plt.subplots()
        df[selected_column].plot(ax=ax, label='Original')
        df['Moving Average'].plot(ax=ax, label=f'{window_size}-Period Moving Average', linestyle='dashed')
        ax.legend()
        
        self.show_report_window(metrics, "Moving Averages - Fitness Measures", fig)

##    def perform_logistic_regression(self):
##        selected_columns = simpledialog.askstring("Logistic Regression", "Enter dependent variable and independent variables (comma-separated):")
##        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
##        if len(columns) < 2:
##            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
##            return
##        dependent_var, independent_vars = columns[0], columns[1:]
##        X_train, X_test, y_train, y_test = train_test_split(self.data[independent_vars], self.data[dependent_var], test_size=0.2, random_state=42)
##        
##        model = LogisticRegression(max_iter=200)
##        model.fit(X_train, y_train)
##        predictions = model.predict(X_test)
##        accuracy = accuracy_score(y_test, predictions)
##        report = classification_report(y_test, predictions)
##        
##        result = pd.DataFrame({"Actual": y_test, "Predicted": predictions})
##        metrics = pd.DataFrame({'Metric': ['Accuracy'], 'Value': [accuracy]})
##        
##        fig, ax = plt.subplots()
##        ax.hist(predictions, bins=10, alpha=0.5, label="Predicted", color='blue')
##        ax.hist(y_test, bins=10, alpha=0.5, label="Actual", color='green')
##        ax.legend()
##        ax.set_title("Logistic Regression Predictions")
##        
##        self.show_report_window(metrics, "Logistic Regression - Accuracy", fig)
##
##    def perform_decision_tree(self):
##        selected_columns = simpledialog.askstring("Decision Tree", "Enter dependent variable and independent variables (comma-separated):")
##        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
##        if len(columns) < 2:
##            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
##            return
##        dependent_var, independent_vars = columns[0], columns[1:]
##        X_train, X_test, y_train, y_test = train_test_split(self.data[independent_vars], self.data[dependent_var], test_size=0.2, random_state=42)
##        
##        model = DecisionTreeClassifier()
##        model.fit(X_train, y_train)
##        predictions = model.predict(X_test)
##        accuracy = accuracy_score(y_test, predictions)
##        
##        metrics = pd.DataFrame({'Metric': ['Accuracy'], 'Value': [accuracy]})
##        fig, ax = plt.subplots()
##        ax.hist(predictions, bins=10, alpha=0.5, label="Predicted", color='blue')
##        ax.hist(y_test, bins=10, alpha=0.5, label="Actual", color='green')
##        ax.legend()
##        ax.set_title("Decision Tree Predictions")
##        
##        self.show_report_window(metrics, "Decision Tree - Accuracy", fig)
    
    def perform_random_forest(self):
        selected_columns = simpledialog.askstring("Random Forest", "Enter dependent variable and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = train_test_split(self.data[independent_vars], self.data[dependent_var], test_size=0.2, random_state=42)
        
        model = RandomForestClassifier()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        
        metrics = pd.DataFrame({'Metric': ['Accuracy'], 'Value': [accuracy]})
        fig, ax = plt.subplots()
        ax.hist(predictions, bins=10, alpha=0.5, label="Predicted", color='blue')
        ax.hist(y_test, bins=10, alpha=0.5, label="Actual", color='green')
        ax.legend()
        ax.set_title("Random Forest Predictions")
        
        self.show_report_window(metrics, "Random Forest - Accuracy", fig)
    
    def get_train_test_split(self, independent_vars, dependent_var):
        train_size = simpledialog.askfloat("Train-Test Split", "Enter training data ratio (e.g., 0.8 for 80%):", minvalue=0.1, maxvalue=0.9)
        if not train_size:
            train_size = 0.8
        return train_test_split(self.data[independent_vars], self.data[dependent_var], test_size=1-train_size, random_state=42)
    
    def evaluate_model(self, model, X_test, y_test, predictions, title):
        accuracy = accuracy_score(y_test, predictions)
        conf_matrix = confusion_matrix(y_test, predictions)
        report = classification_report(y_test, predictions, output_dict=True)
        report_df = pd.DataFrame(report).transpose()
        
        fig, ax = plt.subplots()
        ax.scatter(y_test, predictions, color='blue', label='Predictions')
        ax.plot(y_test, y_test, color='red', linestyle='dashed', label='Perfect Fit')
        ax.legend()
        ax.set_title(f"{title} - Actual vs. Predicted")
        
        self.show_report_window(report_df, f"{title} - Evaluation", fig)
    
    def perform_logistic_regression(self):
        selected_columns = simpledialog.askstring("Logistic Regression", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = LogisticRegression(max_iter=200)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "Logistic Regression")
    
    def perform_decision_tree(self):
        selected_columns = simpledialog.askstring("Decision Tree", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = DecisionTreeClassifier()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "Decision Tree")
    
    def perform_random_forest(self):
        selected_columns = simpledialog.askstring("Random Forest", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = RandomForestClassifier()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "Random Forest")

    def perform_naive_bayes(self):
        selected_columns = simpledialog.askstring("Naive Bayes", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = GaussianNB()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "Naive Bayes")
    
    def perform_knn(self):
        selected_columns = simpledialog.askstring("K-Nearest Neighbors", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = KNeighborsClassifier()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "K-Nearest Neighbors")
    
    def perform_svm(self):
        selected_columns = simpledialog.askstring("Support Vector Machine", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = SVC()
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "Support Vector Machine")
    
    def perform_neural_network(self):
        selected_columns = simpledialog.askstring("Neural Network", "Enter dependent and independent variables (comma-separated):")
        columns = [col.strip() for col in selected_columns.split(',') if col.strip() in self.data.columns]
        if len(columns) < 2:
            messagebox.showerror("Error", "Please enter at least one dependent and one independent variable.")
            return
        dependent_var, independent_vars = columns[0], columns[1:]
        X_train, X_test, y_train, y_test = self.get_train_test_split(independent_vars, dependent_var)
        
        model = MLPClassifier(max_iter=500)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        self.evaluate_model(model, X_test, y_test, predictions, "Neural Network")

    def show_message(self, title, message):
        messagebox.showinfo(title, message)

    def open_python_console(self):
        """Open the Python console for interactive data analysis."""
        PythonConsole(self.root, self)

    def generate_plot(self):
        if self.data is None:
            messagebox.showerror("Error", "No data loaded!")
            return

        selected_columns = simpledialog.askstring("Select Variables", "Enter variable names for plotting (comma-separated):")
        if not selected_columns:
            messagebox.showerror("Error", "No variables selected!")
            return

        selected_columns = [col.strip() for col in selected_columns.split(',')]
        if any(col not in self.data.columns for col in selected_columns):
            messagebox.showerror("Error", "Invalid column names!")
            return

        plot_type = simpledialog.askstring(
            "Plot Type",
            "Enter plot type: 'bar', 'pie', 'box', 'scatter', 'histogram'"
        )
        if not plot_type:
            messagebox.showerror("Error", "No plot type selected!")
            return
        plot_type = plot_type.lower()

        fig, ax = plt.subplots()

        # Handle single variable plots
        if len(selected_columns) == 1:
            var = selected_columns[0]

            if self.data[var].dtype == 'object' or self.data[var].nunique() < 10:
                counts = self.data[var].value_counts()
                if plot_type == 'bar':
                    sns.barplot(x=counts.index, y=counts.values, ax=ax)
                    ax.set_title(f"Bar Plot for {var}")
                elif plot_type == 'pie':
                    ax.pie(counts.values, labels=counts.index, autopct='%1.1f%%', startangle=140)
                    ax.set_title(f"Pie Chart for {var}")
                else:
                    messagebox.showerror("Error", f"'{plot_type}' is not valid for categorical data.")
                    return
            else:
                if plot_type == 'histogram':
                    sns.histplot(self.data[var], kde=True, ax=ax)
                    ax.set_title(f"Histogram with KDE for {var}")
                else:
                    messagebox.showerror("Error", f"'{plot_type}' is only suitable for numeric data.")
                    return

        # Handle two-variable plots
        elif len(selected_columns) == 2:
            var1, var2 = selected_columns
            dtype1 = self.data[var1].dtype
            dtype2 = self.data[var2].dtype

            if (dtype1 == 'object' or self.data[var1].nunique() < 10) and (dtype2 == 'object' or self.data[var2].nunique() < 10):
                if plot_type == 'bar':
                    sns.countplot(x=self.data[var1], hue=self.data[var2], ax=ax)
                    ax.set_title(f"Bar Plot for {var1} and {var2}")
                else:
                    messagebox.showerror("Error", f"'{plot_type}' is not suitable for two categorical variables.")
                    return

            elif (dtype1 == 'object' or self.data[var1].nunique() < 10) or (dtype2 == 'object' or self.data[var2].nunique() < 10):
                categorical_var = var1 if (dtype1 == 'object' or self.data[var1].nunique() < 10) else var2
                numeric_var = var2 if categorical_var == var1 else var1

                if plot_type == 'box':
                    sns.boxplot(x=self.data[categorical_var], y=self.data[numeric_var], ax=ax)
                    ax.set_title(f"Box Plot: {categorical_var} vs {numeric_var}")
                else:
                    messagebox.showerror("Error", f"'{plot_type}' is only suitable for categorical vs numeric.")
                    return

            else:
                if plot_type == 'scatter':
                    sns.scatterplot(x=self.data[var1], y=self.data[var2], ax=ax)
                    ax.set_title(f"Scatter Plot: {var1} vs {var2}")
                elif plot_type == 'histogram':
                    self.data[[var1, var2]].hist(ax=ax, grid=False)
                    fig.suptitle(f"Multiple Histograms for {var1} and {var2}")
                else:
                    messagebox.showerror("Error", f"'{plot_type}' is only suitable for numeric vs numeric.")
                    return

        else:
            messagebox.showerror("Error", "Please select only 1 or 2 variables.")
            return

        self.show_plot_window(fig, "Generated Plot")

    def show_plot_window(self, fig, title):
    
        report_window = Toplevel(self.root)
        report_window.title(title)
        report_window.geometry("800x600")
        
        canvas = FigureCanvasTkAgg(fig, master=report_window)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill='both')
        
        download_button = tk.Button(report_window, text="Download Report", command=lambda: self.download_plot_report(fig, title))
        download_button.pack(anchor='nw', padx=10, pady=5)

##    def download_plot_report(self, fig, title):
##        file_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF File", "*.pdf")])
##        if not file_path:
##            return
##        
##        temp_chart_path = "temp_chart.png"
##        fig.savefig(temp_chart_path)
##        
##        pdf = FPDF()
##        pdf.add_page()
##        pdf.set_font("Arial", size=12)
##        pdf.multi_cell(200, 10, title + "\n\n")
##        pdf.image(temp_chart_path, x=10, y=pdf.get_y(), w=180)
##        pdf.output(file_path)
##        os.remove(temp_chart_path)
##        
##        messagebox.showinfo("Success", "Report saved successfully!")

    def download_plot_report(self, fig, title):
##        if self.license_type == "FULL":
        file_path = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word Document", "*.docx"), ("PDF File", "*.pdf")])
        if not file_path:
            return
        
        temp_chart_path = "temp_chart.png"
        fig.savefig(temp_chart_path)
        
        try:
            if file_path.endswith(".docx"):
                doc = Document()
                doc.add_paragraph(title)
                doc.add_picture(temp_chart_path)
                doc.save(file_path)
            elif file_path.endswith(".pdf"):
                pdf = FPDF()
                pdf.add_page()
                pdf.set_font("Arial", size=12)
                pdf.multi_cell(200, 10, title + "\n\n")
                pdf.image(temp_chart_path, x=10, y=pdf.get_y(), w=180)
                pdf.output(file_path)
        finally:
            if os.path.exists(temp_chart_path):
                os.remove(temp_chart_path)
        
        messagebox.showinfo("Success", "Report saved successfully!")
##        else:
##            messagebox.showinfo("Feature Locked", "Unlock this feature by buying a license. Go to Help menu for more details.")
        
# Run the application
root = tk.Tk()
root.state("zoomed")  # Ensure window is maximized on startup
app = EditableCSVApp(root)
root.mainloop()
